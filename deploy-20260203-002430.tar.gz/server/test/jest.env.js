// Simple Jest environment setup
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-secret';
process.env.DB_NAME = 'patrimonio_db';
process.env.DB_USER = 'siaf_admin';
process.env.DB_HOST = 'localhost';